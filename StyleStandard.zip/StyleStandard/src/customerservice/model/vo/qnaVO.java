package customerservice.model.vo;

import java.util.Date;

public class qnaVO {

	private int qna_num; // 글 번호
	private String user_id; // 작성자 ID
	private String qna_title; // 리뷰 제목
	private String qna_content; // 리뷰 내용
	private Date qna_regdate; // 리뷰 작성일
	
	public int getQna_num() {
		return qna_num;
	}
	public void setQna_num(int qna_num) {
		this.qna_num = qna_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getQna_title() {
		return qna_title;
	}
	public void setQna_title(String qna_title) {
		this.qna_title = qna_title;
	}
	public String getQna_content() {
		return qna_content;
	}
	public void setQna_content(String qna_content) {
		this.qna_content = qna_content;
	}
	public Date getQna_regdate() {
		return qna_regdate;
	}
	public void setQna_regdate(Date qna_regdate) {
		this.qna_regdate = qna_regdate;
	}

	
	
	
}
